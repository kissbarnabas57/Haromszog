﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Haromszogek2._0
{
  class DerekszoguException : Exception
  {
    public DerekszoguException(string message) : base(message)
    {

    }
  }
}
