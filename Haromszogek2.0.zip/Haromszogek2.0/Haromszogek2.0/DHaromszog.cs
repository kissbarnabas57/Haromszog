﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Haromszogek2._0
{
  class DHaromszog
  {
    double aOldal;
    double bOldal;
    double cOldal;
    public double A
    {
      get { return aOldal; }
      set {
        if (value>0)
        {
          aOldal = value;
        }
        else
        {
          throw new OldalnemjoException("Az \'a\'oldal nem lehet negatív vagy nulla");
        }
      }
    }

    public double B
    {
      get { return bOldal; }
      set
      {
        if (value > 0)
        {
          bOldal = value;
        }
        else
        {
          throw new OldalnemjoException("Az \'b\'oldal nem lehet negatív vagy nulla");
        }
      }
    }
    

    public double C
    {
        get { return cOldal; }
        set {
          if (value > 0)
          {
            cOldal = value;
          }
          else
          {
            throw new OldalnemjoException("Az \'c\'oldal nem lehet negatív vagy nulla");
          }
        }
      }
    private bool ellderekszogu;

    public bool Ellderekszogu
    {
      get { return Math.Pow(aOldal, 2) + Math.Pow(bOldal, 2) == Math.Pow(cOldal, 2); }
    }
    private bool ellmegszerkesztheto;

    public bool Ellmegszerkesztheto
    {
      get { return aOldal + bOldal > cOldal; }
    }
    private bool ellnovekvosorrend;

    public bool Ellnovekvosorrend
    {
      get { return aOldal <= bOldal && bOldal <= cOldal; }
    }
    private double kerulet;

    public double Kerulet
    {
      get { return kerulet; }
    }
    private int sorszama;

    public int Sorszama
    {
      get { return sorszama; }
      set { sorszama = value; }
    }
    private double terulet;

    public double Terulet
    {
      get { return terulet; }
    }

     public DHaromszog(string adatok)
    {
      string[] o = adatok.Split(' ');

      A = Convert.ToDouble(o[0]);
      B = Convert.ToDouble(o[1]);
      C = Convert.ToDouble(o[2]);

      if (!Ellnovekvosorrend)
      {
        throw new NovekvoSorrend("Az adatok nincsenek növekvő rendben!");
      }
      if (!Ellmegszerkesztheto)
      {
        throw new MegszerkeszthetoException("A háromszöget nem lehet megszerkeszteni!");
      }
      if (!Ellderekszogu)
      {
        throw new DerekszoguException("A háromszög nem derékszögű!");
      }
    }
    
  }
}

